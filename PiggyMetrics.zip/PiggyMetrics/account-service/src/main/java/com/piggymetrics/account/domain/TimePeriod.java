package com.piggymetrics.account.domain;

public enum TimePeriod {

	YEAR, QUARTER, MONTH, DAY, HOUR

}
